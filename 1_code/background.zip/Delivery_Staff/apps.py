from django.apps import AppConfig


class DeliveryStaffConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Delivery_Staff'
