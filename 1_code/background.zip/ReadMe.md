# Smelly-Tofu 后端


分配给PeterPig
还没定好用什么语言，目测可能是Python？

---

## 规划V1：

使用python作为后端基础语言，web框架为 `Django` 与 `Flask` 二选一
应该就是 `Django` 了， Web API 界面使用 `Swagger UI` 实现。